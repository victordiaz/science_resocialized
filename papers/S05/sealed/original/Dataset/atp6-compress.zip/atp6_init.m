try
    f_instructions();
    
    
    %MANIPULATIONS (conditions);
    ntrials = [100];
    c1onset = [6:10];
    soa = [1:10];
    speed = 40; % speed=degrees per step
    predictability = [1 4]; % 1: random; 2: random, ordered; 3: ordered, random; 4: ordered;
    randstep = speed;
    practice.ntrials = 2;
    practice.conditions = [5 1 2;
                           1 8 1;
                           3 6 2;
                           2 4 1;
                           4 9 2];
    blockarrange = [1 1 1 1];
    for i =[1:length(c1onset)]
        for j =[1:length(soa)]
            for k = [1:length(predictability)]
                blockcond(1).conditions((i-1)*length(soa)*length(predictability)+(j-1)*length(predictability)+k, :) = [i j k];
            end
        end
    end

    
    
    desiredFramerate = 120;
    allscreens.live = Screen(0, 'openwindow', 255, [1 1 2 2], 8); %, 64
    settings.hz = FrameRate(allscreens.live);
    
    angles = [1:1:360];
        
    rect=SCREEN(allscreens.live,'Rect');
    setmouse(0,0);
    window.xmax = rect(3);
    window.ymax = rect(4);
    window.xmid = window.xmax/2;
    window.ymid = window.ymax/2;

    %setup details;
    monitor.diag = 18*2.54; %ends in cm
    monitor.x = (monitor.diag/5)*4;
    monitor.y = (monitor.diag/5)*3;
    monitor.rlum = .5; %-very- rough estimate of R/G intensity ratio

    window.degtopix = window.xmax/monitor.x;
    
    settings.debug = false;
    settings.alpha = 0.04;

    settings.stim.fontsize = 64;
    settings.stim.font = 'Courier'; %in cm/degrees -- assuming 57.4 cm viewing distance
    settings.stim.fontcol = 3; 
    settings.stim.contrast = 1;% [1:0] not used when testing stimContrast
    settings.stim.size = round(3*window.degtopix/2); %in cm/degrees -- assuming 57.4 cm viewing distance
    settings.stim.width = 5; %in cm/degrees -- assuming 57.4 cm viewing distance
    settings.stim.length = round(1*settings.stim.size); %in cm/degrees -- assuming 57.4 cm viewing distance
    settings.stim.color = 3; 
    settings.stim.contrast = 1;% [1:0] not used when testing stimContrast
    settings.stim.n = 26; % how many items total (should be even)?
    settings.stim.ttime = 10;
    settings.stim.stime = 3; 
    settings.stim.ctime = 7;
    settings.stim.possible = char([kbName('A'):kbName('Z')]);
    for i=[1:length(settings.stim.possible)]
        settings.stim.accept{i} = settings.stim.possible(i);
    end

    settings.cue.indiameter = 2.2; %in cm/degrees
    settings.cue.outdiameter = 3.1;
    settings.cue.contrast = 1;% [1:0] not used when testing cue contrast
    settings.cue.color = 3;% [1:0] not used when testing cue contrast
    settings.cue.size = round(settings.cue.outdiameter*window.degtopix/2); %in pixels
    settings.cue.inner = round(settings.cue.indiameter*window.degtopix/2); %in cm/degrees
    settings.cue.outer = round(settings.cue.outdiameter*window.degtopix/2);
    
    fixation.inner = 2; %in pixels/2
    fixation.outer = 4;

    settings.times.fixation = .7; %n secs
    settings.times.pretest = 30; %n frames
    settings.times.posttest = 75; %n frames
    settings.times.fb = 225; % n frames

    %feedback settings
    settings.feedback.duration = .25;
    settings.feedback.cor_hz = 5000;
    settings.feedback.inc_hz = 3000;
    settings.feedback.col = 3;
    settings.feedback.x = round(window.xmid-250);
    settings.feedback.y = round(window.ymid-50);

    %initialization junk
    colors.black = 255;
    colors.white = 3;
    colors.range = colors.black - colors.white;
    colors.mid = colors.white+round(colors.range/2);
    colors.red = 1;
    colors.green = 2;
    colors.empty = 0;

    % set CLUT;
    count = colors.range;
    window.theClut(colors.empty+1,:) = [0 0 0];
    window.theClut(colors.red+1,:) = [255 0 0];
    window.theClut(colors.green+1,:) = [0 round(monitor.rlum*255) 0];
    for i=[colors.white:colors.black]
        window.theClut(i+1,:) = [round(count * (255/colors.range)) round(count * (255/colors.range)) round(count * (255/colors.range))];
        count = count-1;
    end

    err = screen(allscreens.live, 'SetClut', window.theClut, 0, 8);
%     err = screen(allscreens.live, 'SetClut', round(gray(255)*255), 0, 8);
    for i=[1:(settings.stim.n)]
%         for j=[1:10]
            allscreens.stimScreen(i) = screen(0, 'openoffscreenwindow', colors.black, [0 0 window.xmax window.ymax], 8); %,  64
%         end
    end
    allscreens.clean = Screen(0, 'openoffscreenwindow', colors.black, [0 0 window.xmax window.ymax], 8); %,  64
    allscreens.cue = Screen(0, 'openoffscreenwindow', colors.black, [0 0 window.xmax window.ymax], 8); %,  64
    allscreens.fixation = Screen(0, 'openoffscreenwindow', colors.black, [0 0 window.xmax window.ymax], 8); %,  64
    
    Screen(allscreens.fixation, 'FillOval', colors.white, [window.xmid - fixation.outer window.ymid-fixation.outer window.xmid+fixation.outer window.ymid+fixation.outer]);
    Screen(allscreens.fixation, 'FillOval', colors.black, [window.xmid - fixation.inner window.ymid-fixation.inner window.xmid+fixation.inner window.ymid+fixation.inner]);
    Screen(allscreens.cue, 'FillOval', round(colors.black - colors.range * settings.cue.contrast), [window.xmid - settings.cue.outer window.ymid-settings.cue.outer window.xmid+settings.cue.outer window.ymid+settings.cue.outer]);
    Screen(allscreens.cue, 'FillOval', colors.black, [window.xmid - settings.cue.inner window.ymid-settings.cue.inner window.xmid+settings.cue.inner window.ymid+settings.cue.inner]);
    
    disp('init done\n')
    
catch
    clear mex;
    lasterr
    return;
end