clear all;
clc;

prefix = 'atp6';
fileprefix = 'atp61';
f_init = str2func(sprintf('%s_init', prefix));
f_trial = str2func(sprintf('%s_trial', prefix));
f_instructions = str2func(sprintf('%s_instructions', prefix));

[sid, ses, filename] = getSID(sprintf('%s_test', fileprefix));

if(ses == 999)
    load(filename);
    disp(strcat('loaded: ', filename))
else
    sess = ses;
end

f_init();

blocks = blockarrange(1,:);

if(round(settings.hz)~=desiredFramerate)
    clear mex;
    disp(strcat('framerate is: ' , num2str(settings.hz)))
    return;
end

try
    SCREEN('CopyWindow',allscreens.fixation,allscreens.live);

    if(exist('block') == 0)
        datamatrix = [];
        block = 0;
        totalscore = 0;
    end
    
    while(block <= length(blocks))
        if(block>0)
            blocktype = blocks(block);
            conditions = blockcond(blocktype).conditions;
            trialnum = ntrials(blocktype);
        else
            trialnum = practice.ntrials;
            conditions = practice.conditions;
            blocktype = 0;
        end
        
        printText(allscreens.live, textfb.blockstart{blocktype+1}, settings.feedback.col, [0.5 0.5], [0 0], allscreens.clean);
        pause(.1);
        response = getResponse({'space'});
        
        SCREEN('CopyWindow',allscreens.fixation,allscreens.live);
        if(exist('trial') == 0)
            trial = 1;
            curorder = 0;
            thistrial.score = 0;
        end
        while(trial <= trialnum)           
            if(blocktype == 0)
                response = getResponse({'space'});
                err = screen(allscreens.live, 'SetClut', window.theClut, 0, 8);
                printText(allscreens.live, textfb.practice{trial}, settings.feedback.col, [0.5 0.5], [0 0], allscreens.clean);
                response = getResponse({'space'});
                condition = trial;
            else
                [condition, curorder] = randTrial(trial, length(conditions), curorder);
            end

            thistrial.c1onset = c1onset(conditions(condition, 1));
            thistrial.soa = soa(conditions(condition, 2));
            thistrial.predict = predictability(conditions(condition, 3));
            thistrial.trial = trial;
            thistrial.block = block;
            thistrial.offset = unidrnd(26);
            thistrial.speed = speed*(round(rand())-.5)*2;
            
            if(thistrial.soa == 0)
                thistrial.soacalc = soa(ceil(rand()*length(soa)));
            else
                thistrial.soacalc = thistrial.soa;
            end
            thistrial.c2onset = thistrial.c1onset + thistrial.soacalc;
            
            
            if(thistrial.predict == 1) % fully random
                ord1 = randperm(settings.stim.n);
                thistrial.letters = mod(ord1+thistrial.offset - 1, settings.stim.n)+1;
            elseif(thistrial.predict == 4) % ful motion
                ord1 = [1:settings.stim.n];
                thistrial.letters = mod(ord1+thistrial.offset -1, settings.stim.n) +1
            end 
            
            if(trial >1 && block>0)
                thistrial.score = datamatrix(block, trial-1).score;
            end
            usedlet = zeros(1,length(settings.stim.possible));
            
            [datamatrix, bad] = f_trial(thistrial, datamatrix, settings, window, allscreens, textfb);
            if(bad)
                filen = strcat(filename, '_quit');
                disp('Quit.  Session info saved to: ')
                disp(filen)
                disp(filename)
                save(filen);
                save(filename);
                return;
            end
            
            save(filename);
            trial = trial+1;
        end
        if(blocktype ~= 0)
            totalscore = totalscore + datamatrix(block, trial-1).score;
        end
        clear trial;
        save(filename);
        block = block+1;
    end
    fprintf('Total Earned: $%0.3g\n', totalscore/100);
    clear mex;
catch
    clear mex;
    [err, id] = lasterr
    return;
end

clear mex;