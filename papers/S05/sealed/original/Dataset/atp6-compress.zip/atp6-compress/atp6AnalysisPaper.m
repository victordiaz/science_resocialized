% function at5Analysis1(sids)
% edited by Michael Barnett-Cowan for reproducibility project
% MBC: issues include one of the t-tests not working (lines 409-415)
% 2012b won't display Legends? works on 2006a...
%
close all;
clear all;
c1onset = [6:10];
soa = [1:10];
ordconds = [1 2];
sids = [4000 4001 4002 4003 4004 4005 4006 4007 4009 4010 4011 4012]; %  Replicaiton dataset % 4008 crashed before end
%sids = [1002 2001 2002 3000 3001 3006 3010 3012 3015 3018 3021 3023]; % Vul dataset %%[2001:2005]; %
% sids = [654, 353, 338, 3nitems+idxoffset, 354, 348];
% sids = [1001:1003, 1005, 1006];


colorsDet = {'rs-', 'Color',  [1 0 0],   'LineWidth',2, 'MarkerEdgeColor','k', 'MarkerFaceColor', [1 0 0],   'MarkerSize',6;
             'yd--', 'Color', [.7 .3 0], 'LineWidth',2, 'MarkerEdgeColor','k', 'MarkerFaceColor', [.7 .3 0], 'MarkerSize',6;
             'go-', 'Color',  [0 .9 0],  'LineWidth',2, 'MarkerEdgeColor','k', 'MarkerFaceColor', [0 .9 0],   'MarkerSize',6;
             'b<--', 'Color', [0 0 1],   'LineWidth',2, 'MarkerEdgeColor','k', 'MarkerFaceColor', [0 0 1],   'MarkerSize',6;
             'm>-', 'Color',  [.7 0 .7], 'LineWidth',2, 'MarkerEdgeColor','k', 'MarkerFaceColor', [.7 0 .7], 'MarkerSize',6;
             'r^--', 'Color', [1 0 0],   'LineWidth',2, 'MarkerEdgeColor','k', 'MarkerFaceColor', [1 0 0],   'MarkerSize',6;
             'yv-', 'Color',  [.7 .3 0], 'LineWidth',2, 'MarkerEdgeColor','k', 'MarkerFaceColor', [.7 .3 0], 'MarkerSize',6;
             'gp--', 'Color', [0 .9 0],  'LineWidth',2, 'MarkerEdgeColor','k', 'MarkerFaceColor', [0 .9 0],   'MarkerSize',6;
             'bh-', 'Color',  [0 0 1],   'LineWidth',2, 'MarkerEdgeColor','k', 'MarkerFaceColor', [0 0 1],   'MarkerSize',6;
             'co--', 'Color', [0 .7 .7], 'LineWidth',2, 'MarkerEdgeColor','k', 'MarkerFaceColor', [0 .7 .7], 'MarkerSize',6;
             'cs--', 'Color', [0 .7 .7], 'LineWidth',2, 'MarkerEdgeColor','k', 'MarkerFaceColor', [0 .5 .5], 'MarkerSize',6;
             'mo-', 'Color',  [.5 0 .5], 'LineWidth',2, 'MarkerEdgeColor','k', 'MarkerFaceColor', [.5 0 .5], 'MarkerSize',6};


titem = 83.333;
window = [-3:3];
twindow = window.*titem+8.33*7;
idxoffset = max(c1onset);%+max(soa);
idxoffset2 = max(c1onset)+max(soa);


warning off;

colors = {'bo-', 'ro-', 'go-', 'mo-', 'co-', 'ko-', 'yo-'};

nitems = 26;

ns{1} = zeros(length(sids), length(ordconds), length(soa),  nitems+max(c1onset)+max(soa));
ts{1} = zeros(length(sids), length(ordconds), length(soa));
ns{2} = zeros(length(sids), length(ordconds), length(soa),  nitems+max(c1onset)+max(soa));
ts{2} = zeros(length(sids), length(ordconds), length(soa));
ns{3} = zeros(length(sids), length(ordconds), length(soa),  nitems+max(c1onset)+max(soa));
ts{3} = zeros(length(sids), length(ordconds), length(soa));
ns{4} = zeros(length(sids), length(ordconds), length(soa),  nitems+max(c1onset)+max(soa));
ts{4} = zeros(length(sids), length(ordconds), length(soa));
avgs{1} = zeros(length(ordconds), length(soa),  nitems+max(c1onset)+max(soa));
avgs{2} = zeros(length(ordconds), length(soa),  nitems+max(c1onset)+max(soa));
avgs{3} = zeros(length(ordconds), length(soa),  nitems+max(c1onset)+max(soa));
avgs{4} = zeros(length(ordconds), length(soa),  nitems+max(c1onset)+max(soa));
stders{1} = zeros(length(ordconds), length(soa),  nitems+max(c1onset)+max(soa));
stders{2} = zeros(length(ordconds), length(soa),  nitems+max(c1onset)+max(soa));
stders{3} = zeros(length(ordconds), length(soa),  nitems+max(c1onset)+max(soa));
stders{4} = zeros(length(ordconds), length(soa),  nitems+max(c1onset)+max(soa));

avgs{5} = zeros(length(ordconds), length(soa),  nitems+max(c1onset)+max(soa));
stders{5} = zeros(length(ordconds), length(soa),  nitems+max(c1onset)+max(soa));
ns{5} = zeros(length(sids), length(ordconds), length(soa),  nitems+max(c1onset)+max(soa));
ts{5} = zeros(length(sids), length(ordconds), length(soa));

ns{6} = zeros(length(sids), length(ordconds), length(soa),  nitems+max(c1onset)+max(soa));
ts{6} = zeros(length(sids), length(ordconds), length(soa));

ns{7} = zeros(length(sids), length(ordconds), length(soa),  nitems+max(c1onset)+max(soa));
ts{7} = zeros(length(sids), length(ordconds), length(soa));
ns{8} = zeros(length(sids), length(ordconds), length(soa),  nitems+max(c1onset)+max(soa));
ts{8} = zeros(length(sids), length(ordconds), length(soa));

ns{9} = zeros(length(sids), length(ordconds), length(soa),  nitems+max(c1onset)+max(soa));
ts{9} = zeros(length(sids), length(ordconds), length(soa));
tscore = 0
tpossible = 0;
count = 0;
fprintf('SID\tblock\ttrial\tresp1\tresp2\tc1onset\tsoa\tsoacalc\tc1r\tresp1norm2c1\tresp2norm2c1\tresp1norm2c2\tresp2norm2c2\n');
for sud=sids
    ssidx = find(sids==sud);
    count = count + 1;
    clear datamatrix;
    load(sprintf('data/atp61_test_%d_1.mat', sud), 'datamatrix');

    [nb nt] = size(datamatrix);

    for block=[1:nb]
        for trial=[1:nt]
            if(datamatrix(block, trial).soa > 0)
                clear temp;
                temp = datamatrix(block, trial);
                temp.soacalc = temp.soa;
                correct = 0;

                soaidx = find(soa==temp.soa);
                ordcond = temp.predictability;
                if(ordcond == 4)
                    ordcond = 2;
                end
                c1idx = find(c1onset==temp.c1onset);

                temp.resp1 = find(temp.letters == temp.resp1);
                temp.resp2 = find(temp.letters == temp.resp2);
                r1pos2 = (temp.resp1-temp.c1onset-temp.soacalc+idxoffset2);
                r2pos2 = (temp.resp2-temp.c1onset-temp.soacalc+idxoffset2);
                r1pos = (temp.resp1-temp.c1onset+idxoffset);
                r2pos = (temp.resp2-temp.c1onset+idxoffset);
                %             if(temp.resp1-temp.c1onset == 0)
                %                 r1pos - idxoffset
                %             elseif(temp.resp2-temp.c1onset == 0)
                %                 r2pos - idxoffset
                %             end
                tscore = tscore + sum(temp.correct);
                tpossible = tpossible + 2;

                if((temp.resp1 == temp.c1onset) && (temp.soa>0))
                    ns{1}(ssidx, ordcond, soaidx, r2pos) = ns{1}(ssidx, ordcond, soaidx, r2pos) + 1;
                    ts{1}(ssidx, ordcond, soaidx) = ts{1}(ssidx, ordcond, soaidx) + 1;
                    correct = 1;
                elseif((temp.resp2 == temp.c1onset) && (temp.soa>0))
                    ns{1}(ssidx, ordcond, soaidx, r1pos) = ns{1}(ssidx, ordcond, soaidx, r1pos) + 1;
                    ts{1}(ssidx, ordcond, soaidx) = ts{1}(ssidx, ordcond, soaidx) + 1;
                    correct = 1;
                elseif(temp.soa == 0)
                    ns{3}(ssidx, ordcond, soaidx, r1pos) = ns{3}(ssidx, ordcond, soaidx, r1pos) + 1;
                    ns{3}(ssidx, ordcond, soaidx, r2pos) = ns{3}(ssidx, ordcond, soaidx, r2pos) + 1;
                    ts{3}(ssidx, ordcond, soaidx) = ts{3}(ssidx, ordcond, soaidx) + 2;
                else
                    ns{2}(ssidx, ordcond, soaidx, r1pos) = ns{2}(ssidx, ordcond, soaidx, r1pos) + 1;
                    ns{2}(ssidx, ordcond, soaidx, r2pos) = ns{2}(ssidx, ordcond, soaidx, r2pos) + 1;
                    ts{2}(ssidx, ordcond, soaidx) = ts{2}(ssidx, ordcond, soaidx) + 2;
                end
                ns{4}(ssidx, 1, soaidx, r1pos) = ns{4}(ssidx, 1, soaidx, r1pos) + 1;
                ns{4}(ssidx, 1, soaidx, r2pos) = ns{4}(ssidx, 1, soaidx, r2pos) + 1;
                ts{4}(ssidx, 1, soaidx) = ts{4}(ssidx, 1, soaidx) + 2;
                ns{5}(ssidx, ordcond, soaidx, r1pos2) = ns{5}(ssidx, ordcond, soaidx, r1pos2) + 1;
                ns{5}(ssidx, ordcond, soaidx, r2pos2) = ns{5}(ssidx, ordcond, soaidx, r2pos2) + 1;
                ts{5}(ssidx, ordcond, soaidx) = ts{5}(ssidx, ordcond, soaidx) + 2;

                ns{6}(ssidx, 1, soaidx, r1pos) = ns{6}(ssidx, 1, soaidx, r1pos) + 1;
                ts{6}(ssidx, 1, soaidx) = ts{6}(ssidx, 1, soaidx) + 1;


                ns{7}(ssidx, 1, soaidx, r2pos) = ns{7}(ssidx, 1, soaidx, r2pos) + 1;
                ts{7}(ssidx, 1, soaidx) = ts{7}(ssidx, 1, soaidx) + 1;

                ns{8}(ssidx, 1, soaidx, r1pos) = ns{8}(ssidx, 1, soaidx, r1pos) + 1;
                ts{8}(ssidx, 1, soaidx) = ts{8}(ssidx, 1, soaidx) + 1;


                if((temp.resp1 == temp.c1onset) && (temp.soa>0))
                    ns{9}(ssidx, 1, soaidx, r2pos) = ns{9}(ssidx, 1, soaidx, r2pos) + 1;
                    ts{9}(ssidx, 1, soaidx) = ts{9}(ssidx, 1, soaidx) + 1;
                end
            end
        end
    end
end

ks = [length(soa) length(soa) length(soa)]
for i=[1:9]
    [sids2, ords, soas, poss] = size(ns{i});
    for j = [1:length(sids)]
        for o = [1:length(ordconds)]
            for k = [1:length(soa)]
                tnorm{i}(j,o,k, :) = ns{i}(j,o,k, :) ./ ts{i}(j,o,k);

                T2skSum{i}(j,o,k) = sum(reshape(ns{i}(j,o,k, window+soa(k)+idxoffset),1,  length(window)))./length(window+soa(k)+idxoffset)./ ts{i}(j,o,k);
                if(isnan(T2skSum{i}(j,o,k))) T2skSum{i}(j,o,k) = 0; end;
                T2skImu{i}(j,o,k) = sum(reshape(ns{i}(j,o,k, window+soa(k)+idxoffset),1,  length(window)).*window)./sum(ns{i}(j,o,k, window+soa(k)+idxoffset));
                if(isnan(T2skImu{i}(j,o,k))) T2skImu{i}(j,o,k) = 0; end;
                T2skIsg{i}(j,o,k) = sum((reshape(ns{i}(j,o,k, window+soa(k)+idxoffset),1,  length(window)).*((window - T2skImu{i}(j,o,k)).^2)))./sum(ns{i}(j,o,k, window+soa(k)+idxoffset));
                if(isnan(T2skIsg{i}(j,o,k))) T2skIsg{i}(j,o,k) = 0; end;
                T2skTmu{i}(j,o,k) = sum(reshape(ns{i}(j,o,k, window+soa(k)+idxoffset),1,  length(window)).*twindow)./sum(ns{i}(j,o,k, window+soa(k)+idxoffset));
                if(isnan(T2skTmu{i}(j,o,k))) T2skTmu{i}(j,o,k) = 0; end;
                T2skTsg{i}(j,o,k) = sum((reshape(ns{i}(j,o,k, window+soa(k)+idxoffset),1,  length(window)).*((twindow - T2skTmu{i}(j,o,k)).^2)))./sum(ns{i}(j,o,k, window+soa(k)+idxoffset));
                if(isnan(T2skTsg{i}(j,o,k))) T2skTsg{i}(j,o,k) = 0; end;

                skew{i}(j,o,k) = sum(reshape(ns{i}(j,o,k, [k-1:k+1]+idxoffset),1,  3).*[-1 0 1])./sum(ns{i}(j,o,k, [k-1:k+1]+idxoffset));
                skew2{i}(j,o,k) = sum(reshape(ns{i}(j,o,k, [k-1:k+1]+idxoffset),1,  3).*[-45 85 185])./sum(ns{i}(j,o,k, [k-1:k+1]+idxoffset));
                skew2sd{i}(j,o,k) = sqrt(sum((reshape(ns{i}(j,o,k, [k-1:k+1]+idxoffset),1,  3).*[-45 85 185] - repmat(skew2{i}(j,o,k), 1, 3)).^2)./sum(ns{i}(j,o,k, [k-1:k+1]+idxoffset)));

                T1skSum{i}(j,o,k) = sum(reshape(ns{i}(j,o,k, window+idxoffset),1,  length(window)))./length(window+idxoffset)./ ts{i}(j,o,k);
                if(isnan(T1skSum{i}(j,o,k))) T1skSum{i}(j,o,k) = 0; end;
                T1skImu{i}(j,o,k) = sum(reshape(ns{i}(j,o,k, window+idxoffset),1,  length(window)).*window)./sum(ns{i}(j,o,k, window+idxoffset));
                if(isnan(T1skImu{i}(j,o,k))) T1skImu{i}(j,o,k) = 0; end;
                T1skIsg{i}(j,o,k) = sum((reshape(ns{i}(j,o,k, window+idxoffset),1,  length(window)).*((window - T1skImu{i}(j,o,k)).^2)))./sum(ns{i}(j,o,k, window+idxoffset));
                if(isnan(T1skIsg{i}(j,o,k))) T1skIsg{i}(j,o,k) = 0; end;
                T1skTmu{i}(j,o,k) = sum(reshape(ns{i}(j,o,k, window+idxoffset),1,  length(window)).*twindow)./sum(ns{i}(j,o,k, window+idxoffset));
                if(isnan(T1skTmu{i}(j,o,k))) T1skTmu{i}(j,o,k) = 0; end;
                T1skTsg{i}(j,o,k) = sum((reshape(ns{i}(j,o,k, window+idxoffset),1,  length(window)).*((twindow - T1skTmu{i}(j,o,k)).^2)))./sum(ns{i}(j,o,k, window+idxoffset));
                if(isnan(T1skTsg{i}(j,o,k))) T1skTsg{i}(j,o,k) = 0; end;

                skewt1{i}(j,1) = sum(reshape(mean(ns{i}(j,:, [-1:1]+idxoffset), 2),1,  3).*[-1 0 1])./sum(mean(ns{i}(j,:, [-1:1]+idxoffset),2));
                skew2t1{i}(j,o,k) = sum(reshape(ns{i}(j,o,k, [-1:+1]+idxoffset),1,  3).*[-45 85 185])./sum(ns{i}(j,o,k, [-1:1]+idxoffset));
                skew2sdt1{i}(j,o,k) = sqrt(sum((reshape(ns{i}(j,o,k, [-1:+1]+idxoffset),1,  3).*[-45 85 185] - repmat(skew2t1{i}(j,o,k), 1, 3)).^2)./sum(ns{i}(j,o,k, [-1:+1]+idxoffset)));

            end

         end
    end
    skewavg{i} = reshape(mean(skew{i}, 1), length(ordconds), length(soa), 1);
    skewstd{i} = reshape(std(skew{i}, 0, 1) ./ (sids2^(1/2)), length(ordconds), length(soa), 1);
    avgs{i} = reshape(mean(tnorm{i}, 1), length(ordconds), length(soa),  poss);
    stderrs{i} = reshape(std(tnorm{i}, 1) ./ (sids2^(1/2)), length(ordconds), length(soa),  poss);
    skewavg2{i} = reshape(mean(skew2{i}, 1), length(ordconds), length(soa), 1);
    skewstd2{i} = reshape(std(skew2{i}, 0, 1) ./ (sids2^(1/2)), length(ordconds), length(soa), 1);
    skew2sdavg2{i} = reshape(mean(skew2sd{i}, 1), length(ordconds), length(soa), 1);
    skew2sdstd2{i} = reshape(std(skew2sd{i}, 0, 1) ./ (sids2^(1/2)), length(ordconds), length(soa), 1);
    skewavgt1{i} = reshape(mean(skewt1{i}, 1), 1,1);
    skewstdt1{i} = reshape(std(skewt1{i}, 0, 1) ./ (sids2^(1/2)), 1,1);
    %     skew2t1avg{i} = reshape(mean(mean(skew2t1{i}, 1))), 1, 1);
    %     skew2t1std{i} = reshape(std(skew2t1{i}, 0, 1) ./ (sids2^(1/2)), 1,1);
    %     skew2sdt1avg{i} = reshape(mean(mean(skew2sdt1{i}, 1)), 1,1);
    %     skew2sdt1std{i} = reshape(std(skew2sdt1{i}, 0, 1) ./ (sids2^(1/2)), 1,1);
    %

    T2skSumMEAN{i} = reshape(mean(T2skSum{i}, 1), length(ordconds), length(soa), 1);
    T2skSumSDER{i} = reshape(std(T2skSum{i}, 0, 1) ./ (sids2^(1/2)), length(ordconds), length(soa), 1);
    T2skIsgMEAN{i} = reshape(mean(T2skIsg{i}, 1), length(ordconds), length(soa), 1);
    T2skIsgSDER{i} = reshape(std(T2skIsg{i}, 0, 1) ./ (sids2^(1/2)), length(ordconds), length(soa), 1);
    T2skImuMEAN{i} = reshape(mean(T2skImu{i}, 1), length(ordconds), length(soa), 1);
    T2skImuSDER{i} = reshape(std(T2skImu{i}, 0, 1) ./ (sids2^(1/2)), length(ordconds), length(soa), 1);
    T2skTsgMEAN{i} = reshape(mean(T2skTsg{i}, 1), length(ordconds), length(soa), 1);
    T2skTsgSDER{i} = reshape(std(T2skTsg{i}, 0, 1) ./ (sids2^(1/2)), length(ordconds), length(soa), 1);
    T2skTmuMEAN{i} = reshape(mean(T2skTmu{i}, 1),length(ordconds), length(soa), 1);
    T2skTmuSDER{i} = reshape(std(T2skTmu{i}, 0, 1) ./ (sids2^(1/2)), length(ordconds), length(soa), 1);

    T1skIsgMEAN{i} = reshape(mean(T1skIsg{i}, 1), length(ordconds), length(soa), 1);
    T1skIsgSDER{i} = reshape(std(T1skIsg{i}, 0, 1) ./ (sids2^(1/2)), length(ordconds), length(soa), 1);
    T1skImuMEAN{i} = reshape(mean(T1skImu{i}, 1), length(ordconds), length(soa), 1);
    T1skImuSDER{i} = reshape(std(T1skImu{i}, 0, 1) ./ (sids2^(1/2)), length(ordconds), length(soa), 1);
    T1skTsgMEAN{i} = reshape(mean(T1skTsg{i}, 1), length(ordconds), length(soa), 1);
    T1skTsgSDER{i} = reshape(std(T1skTsg{i}, 0, 1) ./ (sids2^(1/2)), length(ordconds), length(soa), 1);
    T1skTmuMEAN{i} = reshape(mean(T1skTmu{i}, 1), length(ordconds), length(soa), 1);
    T1skTmuSDER{i} = reshape(std(T1skTmu{i}, 0, 1) ./ (sids2^(1/2)), length(ordconds), length(soa), 1);
    T1skSumMEAN{i} = reshape(mean(T1skSum{i}, 1), length(ordconds), length(soa), 1);
    T1skSumSDER{i} = reshape(std(T1skSum{i}, 0, 1) ./ (sids2^(1/2)), length(ordconds), length(soa), 1);

end
skew
%
% colors = {'rx-', 'bx-', 'gx-', 'cx-', 'mx-', 'yx-', 'kx-'};


usesoas = soa;
useA = [6 7 9];
for o = 1;%[1:length(ordconds)]
%     figure();

    for useAx = 1:length(useA)
        %         subplot(3, 1, useAx);
        figure();
        x = [];
        y = [];
        curlegend = {};
        for i=[1:length(usesoas)]

            %         errorbar([1:nitems+idxoffset2]-idxoffset, reshape(avgs{useA(useAx)}(o, i,:), (nitems+idxoffset2),1), reshape(stderrs{useA(useAx)}(o, i,:), (nitems+idxoffset2),1), colorsDet{i,:});
            plot([1:nitems+idxoffset2]-idxoffset, reshape(avgs{useA(useAx)}(o, i,:), (nitems+idxoffset2),1), colorsDet{i,:});
            hold on;
            %         plot([i-1, i+1], [avgs{4}(i, i-1+idxoffset) avgs{4}(i, i+1+idxoffset)].*2, 'k:');
            %         plot([1,52]-26, [chance(i) chance(i)], 'k -');
            x =[x usesoas(i)];
            y = [y avgs{useA(useAx)}(o, i,usesoas(i)+idxoffset)];
            curlegend{i}=sprintf('SOA=%d', i);
        end
        curlegend{length(curlegend)+1}= 'T2 Performance';
        if useAx>1
            plot(x, y, 'ko:', 'linewidth', 3', 'markerSize', 16)
        end
        plot([0 0], [0 1], 'k :');
        title('Distribution of reported letters, normalized to Cue 1 onset');
        if(useAx==1)
            legend(curlegend);
        end
        axis([-4 14 0 0.5]);
        xlabel('Item position normalized to cue 1 onset (0=cue 1)');
        ylabel('Proportion of letters reported from that position.');
    end
end

figure();
if useAx>1
    plot(x, y, 'ko:', 'linewidth', 3', 'markerSize', 16)
end
axis([1 10 0 0.5]);


% 
% usesoas = soa;
% useA = [9];
% for o = 1;%[1:length(ordconds)]
%     figure();
% 
%     for useAx = 1:length(useA)
%         %         subplot(3, 1, useAx);
%         figure();
%         x = [];
%         y = [];
%         curlegend = {};
%         for i=[1:length(usesoas)]
% 
%             %         errorbar([1:nitems+idxoffset2]-idxoffset, reshape(avgs{useA(useAx)}(o, i,:), (nitems+idxoffset2),1), reshape(stderrs{useA(useAx)}(o, i,:), (nitems+idxoffset2),1), colorsDet{i,:});
% %             figure();
%             plot([1:nitems+idxoffset2]-idxoffset, reshape(avgs{useA(useAx)}(o, i,:), (nitems+idxoffset2),1), colorsDet{i,:});
%             hold on;
%             plot([usesoas(i) usesoas(i)], [0 1], 'k :');
%             %         plot([i-1, i+1], [avgs{4}(i, i-1+idxoffset) avgs{4}(i, i+1+idxoffset)].*2, 'k:');
%             %         plot([1,52]-26, [chance(i) chance(i)], 'k -');
%             %         x =[x usesoas(i)];
% 
%             axis([-4 14 0 0.5]);
%             %         y = [y avgs{useA(useAx)}(o, i,usesoas(i)+idxoffset)];
%             %         curlegend{i}=sprintf('SOA=%d', i);
%         end
%     end
% end


colorsBW = {'bx--', 'Color',  [1 0 0],   'LineWidth',2, 'MarkerEdgeColor','k', 'MarkerFaceColor', [1 0 0],   'MarkerSize',6;
             'yd--', 'Color', [.7 .3 0], 'LineWidth',2, 'MarkerEdgeColor','k', 'MarkerFaceColor', [.7 .3 0], 'MarkerSize',6;
             'go-', 'Color',  [0 .9 0],  'LineWidth',2, 'MarkerEdgeColor','k', 'MarkerFaceColor', [0 .9 0],   'MarkerSize',6;
             'b<--', 'Color', [0 0 1],   'LineWidth',2, 'MarkerEdgeColor','k', 'MarkerFaceColor', [0 0 1],   'MarkerSize',6;
             'm>-', 'Color',  [.7 0 .7], 'LineWidth',2, 'MarkerEdgeColor','k', 'MarkerFaceColor', [.7 0 .7], 'MarkerSize',6;
             'r^--', 'Color', [1 0 0],   'LineWidth',2, 'MarkerEdgeColor','k', 'MarkerFaceColor', [1 0 0],   'MarkerSize',6;
             'yv-', 'Color',  [.7 .3 0], 'LineWidth',2, 'MarkerEdgeColor','k', 'MarkerFaceColor', [.7 .3 0], 'MarkerSize',6;
             'gp--', 'Color', [0 .9 0],  'LineWidth',2, 'MarkerEdgeColor','k', 'MarkerFaceColor', [0 .9 0],   'MarkerSize',6;
             'bh-', 'Color',  [0 0 1],   'LineWidth',2, 'MarkerEdgeColor','k', 'MarkerFaceColor', [0 0 1],   'MarkerSize',6;
             'co--', 'Color', [0 .7 .7], 'LineWidth',2, 'MarkerEdgeColor','k', 'MarkerFaceColor', [0 .7 .7], 'MarkerSize',6;
             'cs--', 'Color', [0 .7 .7], 'LineWidth',2, 'MarkerEdgeColor','k', 'MarkerFaceColor', [0 .5 .5], 'MarkerSize',6;
             'mo-', 'Color',  [.5 0 .5], 'LineWidth',2, 'MarkerEdgeColor','k', 'MarkerFaceColor', [.5 0 .5], 'MarkerSize',6};


figure();
%     subplot(3, 1, 1);
errorbar(soa.*titem, T2skSumMEAN{7}(1, soa), T2skSumSDER{7}(1, soa), 'ko-', 'MarkerFaceColor', [.1 .1 .1])
hold on;
%     errorbar(soa.*2, T2skSumMEAN{4}(2, soa), T2skSumSDER{4}(2, soa), colorsDet{5,:})
%     hold on;
errorbar(soa.*titem, T1skSumMEAN{6}(1, soa), T1skSumSDER{6}(1, soa), 'kx--', 'MarkerSize',6)
%     errorbar(soa.*2, T1skSumMEAN{4}(2, soa), T1skSumSDER{4}(2, soa), colorsDet{2,:})
title('Fraction of all reports from window around Target');
%Legend('Target 2', 'Target 1'); %MBC: Not working on 2012b?
xlim([0 850]);
ylim([0.09 0.14]);
xlabel('Target 2-Target 1 SOA (msec)')
ylabel('Mean probability of report');
%     subplot(3, 1, 2);
figure();
errorbar(soa.*titem, T2skImuMEAN{7}(1, soa), T2skImuSDER{7}(1, soa), 'ko-', 'MarkerFaceColor', [.1 .1 .1])
hold on;
%     errorbar(soa.*2, T2skTmuMEAN{4}(2, soa), T2skTmuSDER{4}(2, soa), colorsDet{5,:})
%     hold on;
errorbar(soa.*titem, T1skImuMEAN{6}(1, soa), T1skImuSDER{6}(1, soa), 'kx--', 'MarkerSize',6)
%     errorbar(soa.*2, T1skTmuMEAN{4}(2, soa), T1skTmuSDER{4}(2, soa), colorsDet{2,:})
title('Center of mass of reports in window around Target');
%Legend('Target 2', 'Target 1'); %MBC: Not working on 2012b?
xlim([0 850]);
ylim([-1 1]);
xlabel('Target 2-Target 1 SOA (msec)')
ylabel('Center of mass of reports (items)');
%     subplot(3, 1, 3);
figure();
errorbar(soa.*titem, T2skIsgMEAN{7}(1, soa), T2skIsgSDER{7}(1, soa), 'ko-', 'MarkerFaceColor', [.1 .1 .1])
hold on;
%     errorbar(soa.*2, T2skTsgMEAN{4}(2, soa), T2skTsgSDER{4}(2, soa), colorsDet{5,:})
%     hold on;
errorbar(soa.*titem, T1skIsgMEAN{6}(1, soa), T1skIsgSDER{6}(1, soa), 'kx--', 'MarkerSize',6)
%     errorbar(soa.*2, T1skTsgMEAN{4}(2, soa), T1skTsgSDER{4}(2, soa), colorsDet{2,:})
title('Variance of mass of reports in window around Target');
%Legend('Target 2', 'Target 1');
xlim([0 850]);
ylim([0.5 3.5]);
xlabel('Target 2-Target 1 SOA (msec)')
ylabel('Variance of report position (items)');


clear m;
m{1,1} = reshape(T1skSum{6}(:,1,:), length(sids), length(soa));
m{1,2} = reshape(T2skSum{7}(:,1,:), length(sids), length(soa));
m{2,1} = reshape(T1skImu{6}(:,1,:), length(sids), length(soa));
m{2,2} = reshape(T2skImu{7}(:,1,:), length(sids), length(soa));
m{3,1} = reshape(T1skIsg{6}(:,1,:), length(sids), length(soa));
m{3,2} = reshape(T2skIsg{7}(:,1,:), length(sids), length(soa));

for si = [1:length(sids)]
    fprintf('\n%d', sids(si));
    for measure = [1:3]
        for target = [1:2]
            for soai = [1:10]
                fprintf('\t%2.4f', m{measure, target}(si, soai));
                z(si, measure, target, soai) = m{measure, target}(si, soai);
                me(si, measure, target, soai) = measure;
                ta(si, measure, target, soai) = target;
                so(si, measure, target, soai) = soai;
            end
        end
    end
end
c = reshape(z(:,:,1,:) - z(:,:,2,:),  [length(sids), 3, 10]);

z = z(:);
me = me(:);
ta = ta(:);
so = so(:);

% for i = [1:length(sids)] %MBC: Cannot get this to work with new dataset?
% temp = find(c(i,1,[2:10]) <= 0.0025);
% mins(i,2) = temp(1)+1
% temp = find(c(i,3,[2:10]) >= -0.3);
% mins(i,1) = temp(1)+1;
% end
%[h p ci stats] = ttest(mins(:,1), mins(:,2))
[p, table, stats] = anovan(z, {me ta so}, 'model', 'full')
