% instructions

textfb.corfb = 'correct!';
textfb.anykey = 'Hit any key to begin';
textfb.test = 'Please report the two letters cued by flashed circles.  Report the first letter first (make sure you see it appear on the screen), then the second letter.';

textfb.blockstart = {'Practice trials.  Please contact experimenter to explain the instructions and procedure of the experiment to you.',
                   'Ready to start the next block....  Hit the space bar when you are ready to begin!'};

textfb.practice = {'Explain trials.',
            'Practice trial.'};