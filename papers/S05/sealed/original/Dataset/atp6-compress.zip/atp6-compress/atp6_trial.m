function [datamatrix, bad] = at5_trial(thistrial, datamatrix, settings, window, allscreens, textfb)
    thistrialtime.start = getsecs;
       
    err = screen(allscreens.live, 'SetClut', window.theClut, 0, 8);

    screen('CopyWindow',allscreens.fixation,allscreens.live);
    
    thistrial.c1letter = thistrial.c1onset;
    thistrial.c2letter = thistrial.c2onset;
    
    for i=[1:(settings.stim.n)]
        screen('CopyWindow',allscreens.clean, allscreens.stimScreen(i));
        
        initFont(allscreens.stimScreen(i), settings.stim.font, settings.stim.fontsize);
        let = settings.stim.possible(thistrial.letters(i));
        width = screen(allscreens.stimScreen(i),'TextWidth',let);
        height = width;
        x = round(window.xmid - width/2);
        y = round(window.ymid + height/2);
        screen(allscreens.stimScreen(i), 'DrawText', settings.stim.possible(thistrial.letters(i)), x, y, settings.stim.fontcol);
                
        if((i==thistrial.c1onset) || (i==(thistrial.c2onset)))    
            screen(allscreens.stimScreen(i),'FrameOval',settings.cue.color,[window.xmid - settings.cue.outer window.ymid-settings.cue.outer window.xmid+settings.cue.outer window.ymid+settings.cue.outer],8);
        end
            
            
        
    end
    
    stimorder = zeros(settings.stim.n*2, 2);
    for i=[1:size(stimorder, 1)]
        if(mod(i, 2)==0)
            if(((i/2)+1 == thistrial.c1onset))
                stimorder(i,1) = allscreens.clean;
            else
                stimorder(i,1) = allscreens.clean;
            end
            stimorder(i,2) = settings.stim.ctime;
        else
            stimorder(i,1) = allscreens.stimScreen((i+1)/2);
            stimorder(i,2) = settings.stim.stime;
        end
    end

    thistrialtime.calc = getsecs;
    elapsed = thistrialtime.calc - thistrialtime.start;
    if(elapsed < settings.times.fixation)
        waitsecs(settings.times.fixation - elapsed);
    end

    for i=[1:length(stimorder)]
        screen('CopyWindow',stimorder(i,1),allscreens.live);
        screen(0, 'waitblanking', stimorder(i,2));
%         pause();
        if(settings.debug == true)
            kbwait()
            while(kbcheck)
            end
        end
    end
        
    thistrialtime.stim = getsecs;

    screen('CopyWindow',allscreens.clean,allscreens.live);
    screen(0, 'waitblanking', settings.times.pretest);

    printText(allscreens.live, textfb.test, settings.feedback.col, [0.5 0.5], [0 0], allscreens.clean);
    correct = zeros(1,2);
    for i=[1:2]
        pressedkey(i) = getResponse(cat(2, {'esc'}, settings.stim.accept));
        while((i==2) && (pressedkey(1) == pressedkey(2)))
            pressedkey(i) = getResponse(cat(2, {'esc'}, settings.stim.accept));
        end
        thistrialtime.rt(i) = getsecs;
        if(pressedkey(i) == 0)
            clear mex;
            bad = 1;
            return;
        else
            if((i==1) && (pressedkey(i) == thistrial.letters(thistrial.c1letter)))
                correct(i) = 1;
            elseif((i==2) && (pressedkey(i) == thistrial.letters(thistrial.c2letter)))
                correct(i) = 1;
            else
                correct(i) = 0;
            end
            screen(allscreens.live, 'DrawText', settings.stim.possible(pressedkey(i)), window.xmid - 150 + i*100, window.ymax - 100, settings.stim.fontcol);
        end
    end
    screen(0, 'waitblanking', settings.times.posttest);
    
    thistrial.score = keepScore(thistrial.score, correct, settings.feedback.col, allscreens.live, allscreens.clean);
    screen(0, 'waitblanking', settings.times.fb);

    thistrialtime.end = getsecs;

    if(thistrial.block > 0)
        datamatrix(thistrial.block,thistrial.trial).c1onset = thistrial.c1onset;
        datamatrix(thistrial.block,thistrial.trial).soa = thistrial.soa;
        datamatrix(thistrial.block,thistrial.trial).soacalc = thistrial.soacalc;
        datamatrix(thistrial.block,thistrial.trial).c2onset = thistrial.c2onset;
        datamatrix(thistrial.block,thistrial.trial).predictability = thistrial.predict;
        datamatrix(thistrial.block,thistrial.trial).offset = thistrial.offset;
        datamatrix(thistrial.block,thistrial.trial).speed = thistrial.speed;
        datamatrix(thistrial.block,thistrial.trial).fulltrial = thistrial;
        datamatrix(thistrial.block,thistrial.trial).letters = thistrial.letters;
        datamatrix(thistrial.block,thistrial.trial).correct = correct;  
        datamatrix(thistrial.block,thistrial.trial).pressedkey = pressedkey;   
        datamatrix(thistrial.block,thistrial.trial).resp1 = pressedkey(1);   
        datamatrix(thistrial.block,thistrial.trial).resp2 = pressedkey(2);   
        datamatrix(thistrial.block, thistrial.trial).score = thistrial.score;
        datamatrix(thistrial.block, thistrial.trial).trialtime = thistrialtime;
    end
    bad = 0;